rsync -vrz --exclude-from=exclude.deploy --delete public/ louis@journal-test.loupbrun.ca:/var/www/journal-test.loupbrun.ca/
