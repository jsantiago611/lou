rsync -vrz --exclude-from=exclude.deploy --delete public/ louis@journal.loupbrun.ca:/var/www/journal.loupbrun.ca/
