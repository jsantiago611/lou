module.exports = {
  future: {
    removeDeprecatedGapUtilities: true,
    purgeLayersByDefault: true,
  },
  theme: {
    extend: {
      screens: {
        'sm': '640px',
        // => @media (min-width: 640px) { ... }

        'md': '768px',
        // => @media (min-width: 768px) { ... }

        'lg': '1024px',
        // => @media (min-width: 1024px) { ... }

        'xl': '1600px',
        // => @media (min-width: 1280px) { ... }
      },

      colors: {
        green: '#37542F',
        lime: '#66ff00',
        gray: {
          100: '#E0E6DD',
          500: '#8C9986',
          900: '#353C31',
        },
        black: '#000000',
        white: '#ffffff',
      },
      fontSize: {
        '4xl': '2.5rem',
        '5xl': '4rem',
        '6xl': '5rem'
      },
      fontFamily: {
       'serif': ['Georgia', 'Cambria', 'serif'],
       'mono': ['SFMono-Regular', 'Menlo', 'monospace'],
       'sans': ['soehne-web', 'Helvetica', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
       'main': ['soehne-web', 'Univers', 'Helvetica', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
      letterSpacing: {
        tight: '-.015em'
      },
      lineHeight: {        
       'tight': '1.12',
      }
    }
  },
  variants: {},
  plugins: []
}
