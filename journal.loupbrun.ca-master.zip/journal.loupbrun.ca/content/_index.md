---
title: Accueil
---

Le journal web des idées de <a class="h-card" href="https://loupbrun.ca">Louis-Olivier Brassard.</a>

---

Il héberge de courtes [notes](n) et de plus substantiels [essais](e) sur le [#web](t/web/) et les enjeux numériques, le [#design](t/design/) et la philosophie, la [#typographie](t/typographie/) et la littérature, et bien plus.
