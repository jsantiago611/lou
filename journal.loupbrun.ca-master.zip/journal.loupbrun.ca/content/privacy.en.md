---
title: Privacy Policy
translationKey: privacy
aliases: 
- /privacy/
---

(Note: is the term “policy” relevant for a single-person site?)

## Preamble

- Privacy is a major global issue concerning every citizen.
- Extraction, accumulation and exploitation of behavioral data represent socially, psychologically and economically harmful activities.
- Users should be enabled to browse online content safely in simple, comprehensive ways.
- The information on this page is limited the current site and does not cover privacy related to your Internet service provider.

## Practical Principles

- This web site **does not** track your online activity.
- **It does not** install trackers (through the use of cookies, for example) on your computer.
- **It is not** possible to measure how long you browse this site, if you return, or to correlate your activity on another site (including one of my other sites).
- The content is served over a **secure protocole** (<abbr title="HyperText Transfer Protocole Secure">HTTPS</abbr>), which means intercepted data could not be read.

## Data Collected

- Each visit creates a hit in the server logs.
- A log analysis software ([Webalizer](http://www.webalizer.org/)) produces global statistics on a monthly basis.
- I am the only person able to access these statistics.

**Note: such data is not shared with any third-party, ever.**

## Summary

- This site aims to promote responsible practices regarding privacy.
- This site does not track your browsing activity – not here, nor elsewhere; it does not store personal data, except anonymous visits and does not share it with anyone else.
- The data collected is limited to global traffic on this site.
