---
title: Home
---

Welcome to Louis-Olivier Brassard’s personal online journal.

---

It hosts some brief [notes](n) and a few (more lengthy) [essays](e) on [#web](t/web/) & digital issues, [#design](t/design/) & philosophy, [#typography](t/typography) & literature, and more.

## <mark>Fresh paint!</mark>

You can try out an (experimental) color scheme by [clicking here](#toggle-dark) or by pressing the “d” key.
