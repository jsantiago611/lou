---
title: Fragments
draft: true
description: >
  Drafts, brute materials, collage elements.
  This is a fragments bin.
isNumberedSection: true
---

Drafts, brute materials, collage elements.
This is a fragments bin.
