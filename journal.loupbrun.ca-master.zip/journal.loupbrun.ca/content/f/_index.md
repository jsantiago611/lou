---
title: Fragments
draft: true
description: >
  Brouillons, matériaux bruts, éléments de collage.
  Ceci est un bac à fragments.
isNumberedSection: true
---

Brouillons, matériaux bruts, éléments de collage.
Ceci est un bac à fragments.
