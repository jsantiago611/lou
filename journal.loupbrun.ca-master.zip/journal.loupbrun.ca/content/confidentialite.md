---
title: Politique de confidentialité
translationKey: privacy
---

(Note: est-il pertinent de parler d’une «politique» alors que je suis seul à administrer ce site?)

## Préambule

- La vie privée de chaque citoyen·ne est un enjeu d’importance majeure.
- L’extraction, le partage et l’exploitation des données personnelles sans le consentement explicite des utilisateur·trice·s représentent des activités socialement, psychologiquement et économiquement nuisibles qui doivent être empêchées à tout prix.
- Chacun·e devrait être en mesure de naviguer, le plus simplement possible, à l’abri de toute menace concernant son identité numérique.
- L’information contenue sur cette page se limite à l’hébergement de ce site site web et ne couvre pas les modalités d’accès de votre fournisseur d’accès à Internet.

## Principes pratiques

- Ce site web **ne piste pas** votre activité.
- **Il n’enregistre pas** de traqueur (*cookie*) sur votre ordinateur
- **Il n’est pas** possible de mesurer combien de temps vous naviguez sur ce site, si vous revenez, ou de corréler votre activité sur un autre site (y compris l’un de mes autres sites).
- Le contenu de ce site est servi via un **protocole sécuritaire** (<abbr title="HyperText Transfer Protocole Secure">HTTPS</abbr>), empêchant les données interceptées d’être lues par un intermédiaire.

## Données collectées

- Chaque visite sur ce site web crée automatiquement une entrée dans les fichiers d’accès (*logs*) du serveur avec l’adresse IP de l’appareil.
- Le nombre d’entrées permet de générer des statistiques globales grâce au logiciel libre [Webalizer](http://www.webalizer.org/).
- Je suis la seule personne à pouvoir accéder à ces statistiques.

**Note: ces données ne sont jamais partagées avec aucun tiers, sous aucune condition.**

## En résumé

- Ce site vise à promouvoir des pratiques responsables en matière de vie privée.
- Ce site ne piste pas votre activité – ni ici, ni ailleurs; il n’enregistre pas de données personnelles (à l’exception d’une visite anonyme) et ne les partage avec aucun tiers.
- Les données collectées se limitent au nombre de visites du traffic global.