---
title: About
translationKey: about
aliases:
- /about/
---

This journal is a praise towards simplicity.

It is written by Louis-Olivier Brassard, a young web craftsman reflecting on contemporary issues through design, philosophy, typography, literature and information technology.

The technical issues shaping today’s and tomorrow’s society could only be understood through practical and theoretical knowledge—hence the necessity of a multidisciplinary approach.

A low-tech advocate, Louis-Olivier firmly believes that a better future can only be achieved through a democratic repossession of technology and knowledge by the masses; such repossession could only be accomplished through the means of simplicity—authentic revolution of a <mark>society saturated by complexity</mark>.

## Reach Out

You can contact me by [email](mai&#108;t&#111;&#58;louis&#64;%&#54;C&#111;%&#55;5%70%&#54;2run&#46;ca).

I am also on several platforms, namely:

- Keybase ([@loupbrun](https://keybase.io/loupbrun))
- Telegram ([@loupbrun](https://t.me/loupbrun))
- Mastodon ([@loupbrun@mamot.fr](https://mamot.fr/@loupbrun))
- Twitter ([@_loupbrun](https://twitter.com/_loupbrun))

## Colophon

This site is set in [Söhne](https://klim.co.nz/retail-fonts/soehne/), a typeface designed by Kris Sowersby and released in 2019 through [Klim Type Foundry](https://klim.co.nz/about/).

## License

<p xmlns:dct="http://purl.org/dc/terms/" xmlns:vcard="http://www.w3.org/2001/vcard-rdf/3.0#">
The content of <span property="dct:title">Louis-Olivier Brassard’s Web Journal</span> is placed under a <a rel="license" href="http://creativecommons.org/publicdomain/zero/1.0/"><abbr title="Creative Commons Universal 1.0 - Public Domain Dedication">CC0 1.0 Universal</abbr></a> license (no copyright) by <a rel="dct:publisher" href="https://journal.loupbrun.ca/"><span property="dct:title">Louis-Olivier Brassard</span></a>.
This work is published from:
<span property="vcard:Country" datatype="dct:ISO3166" content="CA" about="https://journal.loupbrun.ca/">Canada</span>.


## Technical Notes

This site is built using [Hugo](https://gohugo.io/), a super fast and flexible static-site generator.

The front-end is developed using [TailwindCSS](https://tailwindcss.com/), an awesome CSS framework to build responsive web interfaces.

The content is archived on a [self-hosted Git repo](https://git.loupbrun.ca/louis/journal.loupbrun.ca/), should you want to have a peek under the hood.

![It’s me! (circa 2016)](https://assets.loupbrun.ca/img/share/louis-pix-foret.png "It’s me!")
