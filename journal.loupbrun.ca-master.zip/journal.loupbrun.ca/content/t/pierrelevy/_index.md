---
title: pierrelevy
t:
- philosophe
---

**Pierre Lévy** est un philosophe, sociologue et chercheur en sciences de l’information et de la communication.
Il est l’inventeur du langage [<abbr title="Information Economy Meta Langauge">IEML</abbr>](https://dev.intlekt.io/).

Son [blogue](https://pierrelevyblog.com/), sa [page Wikipédia](https://fr.wikipedia.org/wiki/Pierre_Lévy_(philosophe)).