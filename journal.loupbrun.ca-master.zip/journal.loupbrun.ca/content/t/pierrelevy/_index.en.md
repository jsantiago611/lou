---
title: pierrelevy
---

**Pierre Lévy** is a philosopher, cultural theorist and researcher in communication studies.
He is the inventor of [<abbr title="Information Economy Meta Langauge">IEML</abbr>](https://dev.intlekt.io/).

His [blog](https://pierrelevyblog.com/), his [Wikipedia page](https://fr.wikipedia.org/wiki/Pierre_Lévy_(philosophe)).