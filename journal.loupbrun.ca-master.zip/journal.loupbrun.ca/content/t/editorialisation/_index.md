---
title: editorialisation
---

> L’éditorialisation désigne l’ensemble des dynamiques qui produisent et structurent l’espace numérique. Ces dynamiques sont les interactions des actions individuelles et collectives avec un environnement numérique particulier.
>
> ([Marcello Vitali-Rosati](http://www.sens-public.org/articles/1184/), 2016)

> L’éditorialisation est l’ensemble des dynamiques qui constituent l’espace numérique et qui permettent, à partir de cette constitution, l’émergence du sens. Ces dynamiques sont le résultat de forces et d’actions différentes qui déterminent après coup l’apparition et l’identification d’objets particuliers (personnes, communautés, algorithmes, plateformes…).
>
> ([Marcello Vitali-Rosati](https://journals.openedition.org/revuehn/371), 2020)