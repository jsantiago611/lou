---
title: À propos de ce journal
translationKey: about
---

Ce journal est un éloge à la simplicité.

Il est tenu par Louis-Olivier Brassard, un jeune artisan du web qui réfléchit aux enjeux contemporains à travers le design, la typographie, la philosophie, la littérature et les technologies numériques.

Sa démarche multidisciplinaire se veut autant critique que réaliste: une action et une réflexion qui passent par une connaissance – pratique et théorique – des enjeux techniques qui conditionnent le vivre-ensemble d’aujourd’hui et de demain.

Tenant du *low-tech*, Louis-Olivier croit fermement que le projet d’un avenir meilleur passe nécessairement par une réappropriation démocratique de la technologie et du savoir par le plus grand nombre; cette réappropriation ne saurait être réalisée autrement que par les voies de la simplicité – authentique révolution, en ce sens, d’une <mark>société saturée par la complexité</mark>.

## Me joindre

N’hésitez pas à m’écrire par [courriel](mai&#108;t&#111;&#58;louis&#64;%&#54;C&#111;%&#55;5%70%&#54;2run&#46;ca).

Je suis présent sur plusieurs plateformes, notamment:

- Keybase ([@loupbrun](https://keybase.io/loupbrun))
- Telegram ([@loupbrun](https://t.me/loupbrun))
- Mastodon ([@loupbrun@mamot.fr](https://mamot.fr/@loupbrun))
- Twitter ([@_loupbrun](https://twitter.com/_loupbrun))

## Colophon

Ce site est composé avec la police de caractères [Söhne](https://klim.co.nz/retail-fonts/soehne/), conçue par Kris Sowersby et parue en 2019 chez [Klim Type Foundry](https://klim.co.nz/about/).

## Licence

<p xmlns:dct="http://purl.org/dc/terms/" xmlns:vcard="http://www.w3.org/2001/vcard-rdf/3.0#">
Le contenu du <span property="dct:title">Journal web de Louis-Olivier Brassard</span> est placé sous licence libre <a rel="license" href="https://creativecommons.org/publicdomain/zero/1.0/deed.fr"><abbr title="Creative Commons universel 1.0 - Transfert dans le Domaine Public">CC0 1.0 Universel</abbr></a> (pas de copyright) par <a rel="dct:publisher" href="https://journal.loupbrun.ca/"><span property="dct:title">Louis-Olivier Brassard</span></a>.
Cette œuvre est publiée au <span property="vcard:Country" datatype="dct:ISO3166" content="CA" about="https://journal.loupbrun.ca/">Canada</span>.
</p>


## Notes techniques

Ce site est construit avec [Hugo](https://gohugo.io/), un générateur de sites statiques flexible et ultra rapide.

Le front-end est développé avec [TailwindCSS](https://tailwindcss.com/), une formidable boîte à outils pour créer des interfaces web adaptatives.

Le contenu est archivé dans un [dépôt Git auto-hébergé](https://git.loupbrun.ca/louis/journal.loupbrun.ca/), si jamais vous souhaitez jeter un coup d’œil sous le capot.

![C’est moi! (vers 2016)](https://assets.loupbrun.ca/img/share/louis-pix-foret.png "C’est moi!")
