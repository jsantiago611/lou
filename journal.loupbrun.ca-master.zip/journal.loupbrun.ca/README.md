# Le journal web de Louis-Olivier Brassard

🔗 https://journal.loupbrun.ca

## 🛠 Installer

Nécessite [NodeJS](https://nodejs.org/) (pour construire [TailwindCSS](https://tailwindcss.com/) avec [PostCSS-CLI](https://github.com/postcss/postcss-cli)).

```bash
npm install
```

## Commandes

### 💻 Local

Pour démarrer un serveur local à l’adresse http://localhost:1313

```bash
make serve  # hugo serve --disableFastRender
```

### ⭐️ Créer…

Une nouvelle note dans `content/n/<000>.md`:

```bash
make n      # ./cmd/new-note.sh
```

Un nouvel essai dans `content/e/<00>.md`:

```bash
make e      # ./cmd/new-essay.sh
```

### 📦 Production

Bâtir le site dans le dossier `public/`:

```bash
make build  # rm -rf public && hugo --minify
```

### 🚀 Déployer

Transférer les fichiers `public/` vers journal.loupbrun.ca

```bash
make deploy  # ./cmd/deploy.sh
```

ou encore:

```bash
make all    # build + deploy
```

## Développement des styles

```bash
npm run serve:styles // assets/styles/styles.dev.css
```

```bash
npm run build:styles // assets/styles/styles.built.css
```

## Images

Les images sont spécifiées en Markdown.

```md
![Légende (souhaitée)](/chemin/vers/img.jpg "Titre (optionnel)")
```

Le rendu des images est codé dans [`t/layouts/_default/_markup/render-image.html`](t/layouts/_default/_markup/render-image.html) (utilisant les balises `<figure>` et `<figcaption>` ainsi que l’attribut `loading="lazy"` sur les images).

Pour rendre les images inversibles sur fond sombre, ajouter le mot `invertable` au **nom de fichier**:

```md
![Image inversible](img-invertable.jpg)
```

Les images devraient être entre **600 px** (minimum, préférable) et **1200 px** (maximum) de largeur.

## Images de partage

OpenGraph: `600x315` (dimensions Facebook).

Spécifier le chemin absolu dans le front-matter YAML. Doit être une **collection** (débuter par un trait `-` ou délimiter par des crochets `[…]`):

```md
---
# YAML front-matter
images:
- /path/to-image.jpg
---
```

## Licence

[CC0 1.0 Universel](LICENSE)